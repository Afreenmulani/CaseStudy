using System;

namespace OnlineBankingSystem.DTOs
{
    public class VerifyOtpDTO
    {
        public string? AccountNo { get; set; }
        public string? OTP { get; set; }

         public int UserId { get; set; } 
    }
}