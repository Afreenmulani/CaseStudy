using System;

namespace OnlineBankingSystem.DTOs
{
    public class ForgetPasswordDTO
{
    public int UserId { get; set; }

    // public string AccountNo { get; set; } 
}
}