using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBankingSystem.DTOs
{
    public class AccountDTO
    {
        public int AccountId { get; set; }
        public string? AccountNo { get; set; }
        public string? AccountName { get; set; }
        public string? AccountType { get; set; }
        public decimal? Balance { get; set; }
        public int UserId { get; set; }
    }

}