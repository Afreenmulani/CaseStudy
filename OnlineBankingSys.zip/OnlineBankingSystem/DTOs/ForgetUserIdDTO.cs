using System;

namespace OnlineBankingSystem.DTOs
{
    public class ForgetUserIdDTO
    {
        public string? AccountNo { get; set; }  // Account number to generate OTP
    }
}