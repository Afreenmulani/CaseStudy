using System;

namespace OnlineBankingSystem.DTOs
{
    public class ResetPasswordDTO
{
    public int UserId { get; set; }
    // public string OTP { get; set; }
    public string NewPassword { get; set; }

     public string ConfirmPassword { get; set; } 
}

}
