using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBankingSystem.DTOs
{
    public class RegistrationDTO
    {

        [Required(ErrorMessage = "Account number is required.")]
        public string? AccountNo { get; set; } // Account number must be between 10 to 18 digits.

         [Required(ErrorMessage = "Login password is required.")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Login password must be between 6 and 20 characters.")]
        [DataType(DataType.Password)]

        public string? LoginPassword { get; set; } // Login password with length validation.
        public string? ConfirmLoginPassword { get; set; } // Confirmation password for login

         [Required(ErrorMessage = "Transaction password is required.")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Transaction password must be between 6 and 20 characters.")]
        [DataType(DataType.Password)]
        public string? TransactionPassword { get; set; } // Transaction password with length validation.
        public string? ConfirmTransactionPassword { get; set; } // Confirmation password for transactions.
    }
}

