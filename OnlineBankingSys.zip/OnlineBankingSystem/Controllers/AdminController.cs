using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.Repositories;
using System.Threading.Tasks;
using OnlineBankingSystem.DTOs;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;

namespace OnlineBankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminRepository _adminRepository;
        private readonly IUserRepository _userRepository;
        private readonly IAccountRepository _accountRepository;
        private readonly IConfiguration _configuration;

        public AdminController(IAdminRepository adminRepository, IUserRepository userRepository, IAccountRepository accountRepository, IConfiguration configuration)
        {
            _adminRepository = adminRepository;
            _userRepository = userRepository;
            _accountRepository = accountRepository;
            _configuration = configuration;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] AdminDTO adminDTO)
        {
            try
            {
                var admin = await _adminRepository.AuthenticateAdminAsync(adminDTO.UserName, adminDTO.Password);
                if (admin == null)
                {
                    return Unauthorized(new { message = "Invalid username or password" });
                }

                // Generate JWT
                var token = GenerateJwtToken(admin);
                return Ok(new { token });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        private string GenerateJwtToken(Admin admin)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, admin.AdminId.ToString()),
                new Claim(ClaimTypes.Name, admin.UserName),
                new Claim(ClaimTypes.Role, "Admin") // Add Admin role
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_configuration["Jwt:ExpireMinutes"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("{actionType}/{id}")]
        public async Task<IActionResult> HandleUserApprovalOrRejection(string actionType, int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                return NotFound(new { message = "User not found." });
            }

            if (actionType.Equals("approve", StringComparison.OrdinalIgnoreCase))
            {
                if (user.Status == "Approved")
                {
                    return BadRequest(new { message = "User is already approved." });
                }

                var userApproved = await _adminRepository.ApproveUserAsync(id);
                if (!userApproved)
                {
                    return BadRequest(new { message = "Error occurred while approving the user." });
                }

                var account = await _accountRepository.GetByUserIdAsync(id);
                return Ok(new { message = "User approved and account created.", user, account });
            }
            else if (actionType.Equals("reject", StringComparison.OrdinalIgnoreCase))
            {
                if (user.Status == "Approved")
                {
                    return BadRequest(new { message = "Cannot reject an already approved user." });
                }
                if (user.Status == "Rejected")
                {
                    return BadRequest(new { message = "User is already rejected." });
                }

                var userRejected = await _adminRepository.RejectUserAsync(id);
                if (!userRejected)
                {
                    return BadRequest(new { message = "Error occurred while rejecting the user." });
                }

                return Ok(new { message = "User rejected successfully." });
            }
            else
            {
                return BadRequest(new { message = "Invalid action type. Use 'approve' or 'reject'." });
            }
        }
    }
}
