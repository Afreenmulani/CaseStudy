using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.DTOs;
using OnlineBankingSystem.Repositories;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace OnlineBankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "User")]
    public class BeneficiaryController : ControllerBase
    {
        private readonly IBeneficiaryRepository _beneficiaryRepository;


        public BeneficiaryController(IBeneficiaryRepository beneficiaryRepository)
        {
            _beneficiaryRepository = beneficiaryRepository;
        }

        [HttpPost("add-beneficiary")]
        public async Task<IActionResult> AddBeneficiary([FromBody] BeneficiaryDTO beneficiaryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (beneficiaryDTO == null)
            {
                return BadRequest("Beneficiary data is required.");
            }


            if (beneficiaryDTO.BeneficiaryAccountNo != beneficiaryDTO.ReenterAccountNo)
            {
                return BadRequest("Account No and Reenter Account No do not match.");
            }


            if (await _beneficiaryRepository.AccountNumberExistsAsync(beneficiaryDTO.BeneficiaryAccountNo))
            {
                return BadRequest("The entered Account No already exists. Please enter another Account No.");
            }


            var beneficiary = new Beneficiary
            {
                BeneficiaryName = beneficiaryDTO.BeneficiaryName,
                BeneficiaryAccountNo = beneficiaryDTO.BeneficiaryAccountNo,
                Nickname = beneficiaryDTO.Nickname,
            };


            var createdBeneficiary = await _beneficiaryRepository.AddBeneficiaryAsync(beneficiary);

            return Ok(new
            {
                BeneficiaryId = createdBeneficiary.BeneficiaryId,
                BeneficiaryName = createdBeneficiary.BeneficiaryName,
                Message = "Beneficiary added successfully."
            });
        }




        // [HttpGet("get-beneficiaries")]
        // public async Task<IActionResult> GetBeneficiaries()
        // {
        //     var beneficiaries = await _beneficiaryRepository.GetBeneficiariesAsync();
        //     return Ok(beneficiaries);
        // }


        // [HttpGet("get-beneficiary/{id}")]
        // public async Task<IActionResult> GetBeneficiary(int id)
        // {
        //     var beneficiary = await _beneficiaryRepository.GetBeneficiaryByIdAsync(id);

        //     if (beneficiary == null)
        //     {
        //         return NotFound("Beneficiary not found.");
        //     }

        //     return Ok(new
        //     {
        //         BeneficiaryId = beneficiary.BeneficiaryId,
        //         BeneficiaryName = beneficiary.BeneficiaryName,
        //         AccountNo = beneficiary.BeneficiaryAccountNo
        //     });
        // }


    }
}
