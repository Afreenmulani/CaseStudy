using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.Repositories;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace OnlineBankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "User")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepository _transactionRepository;

        public TransactionController(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }

        [HttpPost("perform")]
        public async Task<IActionResult> PerformTransaction([FromBody] Transaction transactionRequest)
        {
            if (transactionRequest == null)
            {
                return BadRequest("Transaction data is required.");
            }

            // Ensure valid From and To account numbers are provided
            if (string.IsNullOrWhiteSpace(transactionRequest.FromAcc) || string.IsNullOrWhiteSpace(transactionRequest.ToAcc))
            {
                return BadRequest("Valid From and To account numbers are required.");
            }

            // Fetch the beneficiary using ToAcc (account number)
            var beneficiary = await _transactionRepository.GetBeneficiaryByAccountNumberAsync(transactionRequest.ToAcc);
            if (beneficiary == null)
            {
                return NotFound("Beneficiary not found for the provided To account.");
            }

            // Assign the BeneficiaryId to the transaction
            transactionRequest.BeneficiaryId = beneficiary.BeneficiaryId;

            // Check if the user has sufficient balance for the FromAcc account
            var userAccount = await _transactionRepository.GetAccountByNumberAsync(transactionRequest.FromAcc);
            if (userAccount == null || userAccount.Balance < transactionRequest.Amount)
            {
                return BadRequest("Insufficient balance.");
            }

            // Deduct amount from the user's account and perform the transaction
            userAccount.Balance -= transactionRequest.Amount ?? 0;
            transactionRequest.Date = DateTime.Now;

            var transaction = await _transactionRepository.PerformTransactionAsync(transactionRequest);

            // Mask account numbers for security
            string maskedToAccount = "xxxxxxx" + transactionRequest.ToAcc.Substring(transactionRequest.ToAcc.Length - 3);
            string maskedFromAccount = "xxxxxxx" + transactionRequest.FromAcc.Substring(transactionRequest.FromAcc.Length - 3);

            return Ok(new
            {
                Message = "Transfer Successful",
                ReferenceId = transaction.TransactionId.ToString(),
                Mode = transaction.TransactionType,
                PaidToAccount = maskedToAccount,
                Amount = $"Rs.{transactionRequest.Amount}",
                FromAccount = maskedFromAccount,
                Date = transaction.Date.ToString("dd/MM/yyyy HH:mm:ss"),
                Remarks = transactionRequest.TransactionType
            });
        }

        [HttpGet("history")]
        public async Task<IActionResult> GetTransactionHistory([FromQuery] string accountNumber, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            if (string.IsNullOrWhiteSpace(accountNumber))
            {
                return BadRequest("Account number is required.");
            }

            if (startDate > endDate)
            {
                return BadRequest("Start date must be earlier than or equal to the end date.");
            }

            var transactions = await _transactionRepository.GetTransactionsByAccountAndDateRangeAsync(accountNumber, startDate, endDate);

            if (transactions == null || !transactions.Any())
            {
                return NotFound("No transactions found for the specified account number and date range.");
            }

            var result = transactions.Select(t => new
            {
                t.TransactionId,
                t.FromAcc,
                t.ToAcc,
                t.Amount,
                t.TransactionType,
                Date = t.Date.ToString("dd/MM/yyyy HH:mm:ss"),
                Remarks = "Payment"
            });

            return Ok(result);
        }
    }
}
