using OnlineBankingSystem.Models;
using OnlineBankingSystem.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;



namespace OnlineBankingSystem.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        private readonly BankContext _context;



        public LoginRepository(BankContext context)
        {
            _context = context;
        }



        // Validate UserId and LoginPassword
        public async Task<bool> ValidateLoginAsync(int userId, string loginPassword)
        {
            // Ensure UserId exists in the Accounts table
            var isValidUser = await _context.Accounts
                .AnyAsync(account => account.UserId == userId);

            if (!isValidUser) return false;

            // Validate LoginPassword in the Registrations table for the matching AccountId
            return await _context.Registrations
                .Join(_context.Accounts,
                      registration => registration.AccountId,
                      account => account.AccountId,
                      (registration, account) => new { registration, account })
                .AnyAsync(ra => ra.account.UserId == userId &&
                                ra.registration.LoginPassword == loginPassword);
        }



        public async Task<int?> GetUserIdByAccountNoAsync(string accountNo)
        {
            var account = await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountNo == accountNo); // Query Account based on AccountNo

            return account?.UserId; // Return UserId if Account is found, otherwise return null
        }

        public async Task<bool> UpdatePasswordAsync(int userId, string newPassword)
        {
            // Fetch the registration that is related to the userId
            var registration = await _context.Registrations
                .Where(r => r.Account.UserId == userId)
                .FirstOrDefaultAsync();

            if (registration != null)
            {
                // You can hash the password before saving it for better security
                registration.LoginPassword = newPassword;

                // Save changes to the database
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }




        public async Task<string> GetEmailByAccountNoAsync(string accountNo)
        {
            var account = await _context.Accounts
                .Include(a => a.User) // Ensure related User is loaded
                .FirstOrDefaultAsync(a => a.AccountNo == accountNo);

            return account?.User?.Email; // Return email if available
        }

    }

}