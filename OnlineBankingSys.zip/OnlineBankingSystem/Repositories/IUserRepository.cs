using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public interface IUserRepository
    {
        Task<User> GetByIdAsync(int id);
        Task<User> GetByEmailAsync(string email);
        Task<User> CreateAsync(User user);

    }
}
