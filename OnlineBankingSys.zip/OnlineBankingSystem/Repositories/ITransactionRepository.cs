using OnlineBankingSystem.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Storage;

using System.Collections.Generic;

namespace OnlineBankingSystem.Repositories
{
    public interface ITransactionRepository
    {
        Task<Transaction> PerformTransactionAsync(Transaction transaction);
        Task<Beneficiary?> GetBeneficiaryByAccountNumberAsync(string toAcc);
        Task<Account?> GetAccountByNumberAsync(string accountNumber);
        Task UpdateAccountAsync(Account account);
        Task<IDbContextTransaction> BeginTransactionAsync();
        Task<List<Transaction>> GetTransactionsByAccountAndDateRangeAsync(string accountNumber, DateTime startDate, DateTime endDate);
    }
}
