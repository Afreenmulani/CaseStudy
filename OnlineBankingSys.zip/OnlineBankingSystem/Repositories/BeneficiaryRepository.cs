using Microsoft.EntityFrameworkCore;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public class BeneficiaryRepository : IBeneficiaryRepository
    {
        private readonly BankContext _context;


        public BeneficiaryRepository(BankContext context)
        {
            _context = context;
        }


        public async Task<Beneficiary> AddBeneficiaryAsync(Beneficiary beneficiary)
        {
            _context.Beneficiaries.Add(beneficiary);
            await _context.SaveChangesAsync();
            return beneficiary;
        }


        public async Task<IEnumerable<Beneficiary>> GetBeneficiariesAsync()
        {
            return await _context.Beneficiaries.ToListAsync();
        }


        public async Task<Beneficiary?> GetBeneficiaryByIdAsync(int beneficiaryId)
        {
            return await _context.Beneficiaries
                                 .FirstOrDefaultAsync(b => b.BeneficiaryId == beneficiaryId);
        }



        public async Task<bool> BeneficiaryExistsAsync(string accountNo)
        {
            return await _context.Beneficiaries
                                 .AnyAsync(b => b.BeneficiaryAccountNo == accountNo);
        }

        public async Task<bool> AccountNumberExistsAsync(string accountNo)
        {
            return await _context.Beneficiaries.AnyAsync(b => b.BeneficiaryAccountNo == accountNo);
        }

    }
}
