using OnlineBankingSystem.Models;
using OnlineBankingSystem.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace OnlineBankingSystem.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly BankContext _context;

        public TransactionRepository(BankContext context)
        {
            _context = context;
        }

        public async Task<Transaction> PerformTransactionAsync(Transaction transaction)
        {
            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();
            return transaction;
        }

        public async Task<Beneficiary?> GetBeneficiaryByAccountNumberAsync(string toAcc)
        {
            return await _context.Beneficiaries
                .FirstOrDefaultAsync(b => b.BeneficiaryAccountNo == toAcc);
        }

        public async Task<Account?> GetAccountByNumberAsync(string accountNumber)
        {
            return await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountNo == accountNumber);
        }

        public async Task UpdateAccountAsync(Account account)
        {
            _context.Accounts.Update(account);
            await _context.SaveChangesAsync();
        }

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            return await _context.Database.BeginTransactionAsync();
        }

        public async Task<List<Transaction>> GetTransactionsByAccountAndDateRangeAsync(string accountNumber, DateTime startDate, DateTime endDate)
        {
            return await _context.Transactions
                .Where(t => t.FromAcc == accountNumber && t.Date >= startDate && t.Date <= endDate)
                .OrderBy(t => t.Date)
                .ToListAsync();
        }
    }
}
