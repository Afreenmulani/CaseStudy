using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public interface IAdminRepository
    {
        // Method to approve the user (this will be used by the admin)
        Task<Admin?> AuthenticateAdminAsync(string username, string password);
        Task<bool> ApproveUserAsync(int userId);

        Task<bool> RejectUserAsync(int userId);
    }
}
