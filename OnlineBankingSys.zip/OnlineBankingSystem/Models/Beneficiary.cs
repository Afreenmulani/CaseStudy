using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using Microsoft.Identity.Client;

namespace OnlineBankingSystem.Models
{
    public class Beneficiary
    {
        [Key]
        public int BeneficiaryId { get; set; }

        [Required(ErrorMessage = "Beneficiary name is required.")]
        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Beneficiary name can only contain letters and spaces.")]
        public string? BeneficiaryName { get; set; }

        [Required(ErrorMessage = "Account number is required.")]
        public string? BeneficiaryAccountNo { get; set; }

        public string? Nickname { get; set; }

        public ICollection<Transaction> Transactions { get; set; } = null!;
    }
}