using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using Microsoft.Identity.Client;

namespace OnlineBankingSystem.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }

        public int BeneficiaryId { get; set; }

        public Beneficiary? Beneficiary { get; set; }

        public string? FromAcc { get; set; }

        public string? ToAcc { get; set; }
        public decimal? Amount { get; set; }

        public string? TransactionType { get; set; }

        public DateTime Date { get; set; }
    }
}
