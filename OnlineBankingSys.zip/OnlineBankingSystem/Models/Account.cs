using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using Microsoft.Identity.Client;

namespace OnlineBankingSystem.Models
{
    public class Account
    {
        [Key]
        public int AccountId { get; set; }

        public int UserId { get; set; }
        public User? User { get; set; }

        public string? AccountNo { get; set; }
        public string? AccountName { get; set; }

        public string? AccountType { get; set; }
        public decimal? Balance { get; set; }
    }
}
